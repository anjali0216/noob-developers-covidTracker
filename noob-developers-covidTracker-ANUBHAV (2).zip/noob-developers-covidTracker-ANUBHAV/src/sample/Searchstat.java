package sample;

public class Searchstat {
}
