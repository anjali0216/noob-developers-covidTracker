package sample;

import javafx.scene.control.TextArea;

public class Symptom {
    public TextArea textArea2;
}
